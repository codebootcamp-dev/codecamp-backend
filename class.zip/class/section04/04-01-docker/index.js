console.log("이 파일은 도커 안에서 실행됩니다.")

while(true){
    
}