export function getToday(){
    return "2022-10-02" // 실제로는 new Date()를 사용해서 만들기
}