// const qqq: string = "철수"

// console.log(qqq)

function Controller(aaaaaaaaaaaaa: any){
    console.log("===============")
    console.log(aaaaaaaaaaaaa)
    console.log("===============")
}

@Controller
class CatsController {

}